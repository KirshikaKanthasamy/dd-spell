from flask import Flask, render_template, request
from flask_mysqldb import MySQL
import yaml
import nltk
from nltk.tokenize import word_tokenize
import re
from nltk.util import ngrams
import numpy


app = Flask(__name__)

# configure db
db = yaml.load(open('db.yaml'))
app.config['MYSQL_HOST'] = db['mysql_host']
app.config['MYSQL_USER'] = db['mysql_user']
app.config['MYSQL_PASSWORD'] = db['mysql_password']
app.config['MYSQL_DB'] = db['mysql_db']

mysql = MySQL(app)
checkLettersTamil = ['்', 'ா', 'ி', 'ீ', 'ு', 'ூ', 'ெ', 'ே', 'ை', 'ொ', 'ோ', 'ௌ']
checkLettersSinhala = ['්', 'ා', 'ැ', 'ෑ', 'ි', 'ී', 'ු', 'ූ', 'ෙ', 'ේ', 'ෛ', 'ො', 'ෝ', 'ෞ', 'ෘ', 'ෲ', 'ෟ', 'ෳ', 'ං', 'ඃ']


@app.route('/', methods=['GET', 'POST'])
def index():
    resultList = []
    originalPara = []
    listLength = 0
    cantiResult =[]
    print('request---> ', request)
    if request.method == 'POST':
        # fetch form data
        tamilTextPara = request.form['textAreaId']
        print('input------------>', tamilTextPara)
        tamilTextPara = tamilTextPara.replace('&nbsp;', '**')

        # tamilTextPara = 'kjjh bbhh Tamil News | தமிழ் செய்திகள்'
        originalPara = nltk.word_tokenize(tamilTextPara)
        print('originalPara', originalPara)
        words = clean_text2(tamilTextPara)
        cantiResult = canti_check(words)

        cur = mysql.connection.cursor()
        for inpText in words:
            if find_language(inpText) == 'tamil':
                accKey = getTamilAccKey(inpText ,0)
                query = "SELECT word FROM dictionary WHERE word = %s AND accessKey like %s"
                inputVar = (inpText, accKey)
                result = cur.execute(query, inputVar)

                print("this is query result-> ", result)
                if result == 0:
                    resultList.append(inpText)
            else:
                accKey = getSinhalaAccKey(inpText, 0)
                query = "SELECT word FROM sinhala_dict WHERE word = %s AND accessKey like %s"
                inputVar = (inpText, accKey)
                result = cur.execute(query, inputVar)

                print("this is sinhala query result-> ", result)
                if result == 0:
                    resultList.append(inpText)
        cur.close()
    elif request.method == 'GET':
        print('this is get method')
    else:
        print('something went wrong', request)

    misspelt = []
    sugg_list = []
    sugg_count_list = []
    for word in resultList:
        #index = words.index(word)
        #if (resultList[index] == 'fail'):
        #misspelt.append(word)
        print(suggestion(word))
        sugg_list.append(suggestion(word))
        sugg_count_list.append(len(suggestion(word)))
        # sugg_count_list = len(suggestion(word))
    print('sugg_count_list-> ', sugg_count_list)
    print('sugg_list-> ', sugg_list)
    n = len(resultList)
    print(n)
    return render_template('mainpage.html', resultList=resultList, wordList=originalPara, listLength=len(originalPara), cantiResult=cantiResult, sugg_list=sugg_list, sugg_count_list=sugg_count_list, n=n)


def clean_text2(text):
    # t1 = text.translate(str.maketrans('', '', string.punctuation))
    t1 = re.sub(r"[!@#$%^&*()-_=+{}\|:;?/.>,<''`~]", " ", text)
    t1 = t1.replace('"', ' ')
    words = nltk.word_tokenize(t1)
    wordList = list(words)
    return wordList


def getTamilAccKey(inpText, x):
    if len(inpText) != 1:
        if inpText[1] in checkLettersTamil:
            accKey = inpText[:2] + str(len(inpText) + x) + '%'
        else:
            accKey = inpText[0] + str(len(inpText)+ x) + '%'
    else:
        accKey = inpText[0] + str(len(inpText)+ x) + '%'
    return accKey


def getSinhalaAccKey(inpText, x):
    if len(inpText) != 1:
        if inpText[1] in checkLettersSinhala:
            accKey = inpText[:2] + str(len(inpText) + x) + '%'
        else:
            accKey = inpText[0] + str(len(inpText)+ x) + '%'
    else:
        accKey = inpText[0] + str(len(inpText)+ x) + '%'
    return accKey

def canti_check(words):
    cantiResult = []
    cantiMistake = []
    cantiCorrection =[]
    possible = ["க்", "ச்", "ப்", "த்"]
    for i in range(len(words) - 1):
        if find_language(words[i]) == 'tamil':
            if (words[i][-2:]) in possible:
                if words[i][-2] == words[i + 1][0]:
                    pass
                else:
                    cantiMistake.append(words[i])
                    cantiCorrection.append(words[i][:-2] + words[i + 1][0] + "்")
                    print("Word " + words[i] + " should be changed to " + words[i][:-2] + words[i + 1][0] + "்")
            else:
                pass
    cantiResult.append(cantiMistake)
    cantiResult.append(cantiCorrection)
    return cantiResult


def find_language(word):
    if 3071 >= ord(word[0]) >= 2944:
        return 'tamil'
    else:
        return 'sinhala'


def suggestion(misspelt_word):
    inpText = misspelt_word
    suggest = []
    cur = mysql.connection.cursor()
    freq_dic = {}
    for x in range(-2, 3):
        if find_language(inpText) == 'tamil':
            accKey = getTamilAccKey(inpText, x)
            query = "SELECT word ,freq FROM dictionary WHERE accessKey like %s"
            result = cur.execute(query, [accKey])
            result = cur.fetchall()
            mysql.connection.commit()

        else:
            accKey = getSinhalaAccKey(inpText ,x)
            query = "SELECT word,freq FROM sinhala_dict WHERE accessKey like %s"
            result = cur.execute(query, [accKey])
            result = cur.fetchall()
            mysql.connection.commit()
        for query_output in result:
            word = query_output[0]
            freq = query_output[1]
            ed = nltk.edit_distance(inpText, word)
            if (ed <= 2):
                suggest.append(word)
                freq_dic.update({word: freq})
        ng_list = list(ngrams(inpText, 2))

    sugg_dic = {}


    for word in suggest:
        l = list(ngrams(word, 2))
        lis = set(l + ng_list)
        val = len(list(set(ng_list) & set(l)))
        value = val / (len(lis))
        sugg_dic.update({word: value})

    sorted_x = sorted(sugg_dic.items(), key=lambda kv: kv[1])
    sorted_x = sorted_x[-10:]
    count = len(sorted_x)
    #print(type(sorted_x))
    print(sorted_x)
    sorted_freq = {}
    for word_value in sorted_x:
        sorted_freq.update({word_value[0]:freq_dic.get(word_value[0])})

    sorted_freq = sorted(sorted_freq.items(), key=lambda kv: kv[1])
    print(sorted_x)
    print (freq_dic)

    #val_dict.update(freq_dic)
    print("Suggestions for " + inpText + " :")
    for i in range(len(sorted_freq) - 1, 0, -1):
        print(sorted_freq[i][0], sorted_freq[i][1])
    print("\n")

    cur.close()
    print("Sorted_freq ", sorted_freq)
    return sorted_freq



if __name__ == '__main__':
    app.run(debug=True)

